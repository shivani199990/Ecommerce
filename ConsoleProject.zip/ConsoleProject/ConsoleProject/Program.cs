﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    class Program
    {
        static void Main(string[] args)
        {

            Nullable<int> nullableVariable = 0;
            int intVariable = 1;
            Console.WriteLine(nullableVariable.GetType() == intVariable.GetType());
            Console.Read();

        }
}
}
