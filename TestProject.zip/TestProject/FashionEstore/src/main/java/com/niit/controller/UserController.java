package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.dao.CategoryDao;
import com.niit.dao.ProductDao;
import com.niit.dao.SupplierDao;
import com.niit.dao.UserDao;
import com.niit.daoImpl.CategoryDaoImpl;
import com.niit.daoImpl.UserDaoImpl;

@Controller
public class UserController {
	@Autowired
	private UserDao userDao;
	
	
	
	@RequestMapping("/register")
	public String register()
	{
		return "register";
	}
	@RequestMapping("/success")
	public String success()
	{
		return "success";
	}

}
