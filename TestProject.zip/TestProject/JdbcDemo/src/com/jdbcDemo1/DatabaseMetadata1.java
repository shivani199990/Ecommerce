package com.jdbcDemo1;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

public class DatabaseMetadata1 {

	public static void main(String[] args)throws Exception
	{

		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");
		DatabaseMetaData dbmd=con.getMetaData(); 
		System.out.println("Driver Name: "+dbmd.getDriverName());  
		System.out.println("Driver Version: "+dbmd.getDriverVersion());  
		System.out.println("UserName: "+dbmd.getUserName());  
		System.out.println("Database Product Name: "+dbmd.getDatabaseProductName());  
		System.out.println("Database Product Version: "+dbmd.getDatabaseProductVersion());  
		  
		con.close();  
		
	}

}
