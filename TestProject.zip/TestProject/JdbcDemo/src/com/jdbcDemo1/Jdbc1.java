package com.jdbcDemo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbc1
{
	public static void main(String args[])
	{
		try
		{
			
			Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from emp");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
				con.close();
			}
			System.out.println("Database Connected!!!!1");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
