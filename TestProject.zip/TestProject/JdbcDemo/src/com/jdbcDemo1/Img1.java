package com.jdbcDemo1;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Img1 {

	public static void main(String[] args)
	{
		try{  
			 
			Connection con=DriverManager.getConnection(  
					"jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");  
			              
			PreparedStatement ps=con.prepareStatement("insert into imgtable values(?,?)");  
			ps.setString(1,"sonoo");  
			  
			FileInputStream fin=new FileInputStream("e:\\shivi.jpg");  
			ps.setBinaryStream(2,fin,fin.available());  
			int i=ps.executeUpdate();  
			System.out.println(i+" records affected");  
			          
			con.close();  
			}catch (Exception e) {e.printStackTrace();}  
			}
		
	}


