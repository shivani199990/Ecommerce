package com.jdbcDemo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JdbcDemo2 {

	public static void main(String[] args)throws Exception 
	{
		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");
		Statement stmt=con.createStatement();
		/*int res1=stmt.executeUpdate("insert into emp values(334,'shivani',22)");
		int res2=stmt.executeUpdate("insert into emp values(335,'rishav',20)");
		int res3=stmt.executeUpdate("insert into emp values(336,'shubham',19)");*/
		//int res4=stmt.executeUpdate("update emp set name='anshu',age=16 where id=334");
		int res5=stmt.executeUpdate("delete from emp where id=334");
		System.out.println("updated!!!!");
	}

}
