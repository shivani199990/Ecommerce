package com.jdbcDemo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class PreparedStmt1 {

	public static void main(String[] args)
	{
		try
		{
			Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");
			PreparedStatement stmt=con.prepareStatement("insert into Emp1 values(?,?)");  
			stmt.setInt(1,23);
			stmt.setString(2, "Shivani");
			stmt.setInt(1,24);
			stmt.setString(2, "Shubham");
			int i=stmt.executeUpdate();
			System.out.println(i+" "+"records inserted");
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
