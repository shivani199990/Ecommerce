package com.jdbcDemo1;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Database2 {

	public static void main(String[] args)throws Exception
	{
		Connection con=DriverManager.getConnection(  
				"jdbc:h2:tcp://localhost/~/jd1","shivani","shivani");  
				  
				DatabaseMetaData dbmd=con.getMetaData();  
				String table[]={"TABLE"};  
				ResultSet rs=dbmd.getTables(null,null,null,table);  
				  
				while(rs.next()){  
				System.out.println(rs.getString(3));  
				}  
				  
				con.close();  

	}

}
