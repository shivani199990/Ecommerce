package com.niit.FashionBackend;

import com.niit.daoImpl.UserDaoImpl;
import com.niit.model.User;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        User user=new User("abc@gmail.com","6754432198","jpnagar","12345678","user","india",false,"shivani");
        System.out.println("user object is created");
        UserDaoImpl userdao=new UserDaoImpl();
        System.out.println("UserDaoImpl object created");
        userdao.insertUser(user);
        System.out.println("insert function executed");
        
        
    }
}
