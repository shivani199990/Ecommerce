package com.niit.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.UserDao;
import com.niit.model.User;
//@Repository("UserDao")
@Repository
public class UserDaoImpl implements UserDao{
	

	@Autowired
	SessionFactory sessionFac;
	
/*	public void setSessionFactory(SessionFactory sessionFac)
	{
		this.sessionFac=sessionFac;
	}
	

	public UserDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}


	public UserDaOImpl(SessionFactory sessionFac) {
		super();
		this.sessionFac = sessionFac;
	}*/

	@Transactional
	public void insertUser(User user) {
		System.out.println("entered the impl class");
		try
		{
		sessionFac.getCurrentSession().save(user);
		System.out.println("saved");
		//return true;
		}
		catch(Exception e)
		{
		//return false;
			System.out.println("exception"+e.getMessage());
		}
		System.out.println("committed");
		
	}

}
