﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IBussinessLayer
{
    public interface INewsFeedManager
    {
        Task<OperationResult> PostNews(NewsFeed newsFeed);
        Task<OperationResult> DeleteNews(int id);
        Task<OperationResult> UpdateNews(int id, NewsFeed newsFeed);
        Task<OperationResult> GetNewsList();

    }
}
