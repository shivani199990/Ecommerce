﻿using DriveSafe.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{
    public interface IUserManager
    {
        Task<OperationResult> GetUserDetails(User user);

        Task<OperationResult> SetUserDetails(User user);

        Task<OperationResult> StoreUserLoginDetails(UserLogin userLogin);
        Task<OperationResult> ResetPassword(ChangePassword changePassword);
        Task<OperationResult> UpdatePassword(UserLogin userLogin);
    }
}
