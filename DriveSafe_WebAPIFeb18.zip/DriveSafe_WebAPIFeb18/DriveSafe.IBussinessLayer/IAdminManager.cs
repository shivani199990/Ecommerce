﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IBussinessLayer
{
    public interface IAdminManager
    {
        Task<OperationResult> GetAdminDetails(Admin admin);

        Task<OperationResult> SetAdminDetails(Admin admin);

        Task<OperationResult> StoreAdminLoginDetails(AdminLogin adminLogin);
        Task<OperationResult> VerifyAccessKey(AccessKeyForAdmin accessKey);
        Task<OperationResult> ResetPassword(ChangePassword changePassword);
        Task<OperationResult> UpdatePassword(AdminLogin adminLogin);

    }
}
