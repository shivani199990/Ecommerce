﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IBussinessLayer
{
    public interface IBlogManager
    {
        Task<OperationResult> PostBlog(Blogs blogs);
        Task<OperationResult> DeleteBlog(int BlogId);

        Task<OperationResult> GetBlog();
        Task<OperationResult> GetBlogForUser();
        Task<OperationResult> UpdateBlog(int BlogId, Blogs blogs);
    }
}
