﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IBussinessLayer
{
    public interface IProfileManager
    {
        Task<OperationResult> GetAdminProfile(String emailId);

        Task<OperationResult> GetUserProfile(String emailId);

        Task<OperationResult> UpdateUserProfile(User user);

        Task<OperationResult> UpdateAdminProfile(Admin admin);

      
    }
}
