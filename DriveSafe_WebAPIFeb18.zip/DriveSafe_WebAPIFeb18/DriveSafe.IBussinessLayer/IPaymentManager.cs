﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IBussinessLayer
{
    public interface IPaymentManager
    {
        OperationResult PayAmount(PaymentDetails paymentDetails);
        OperationResult GetPaymentDetails(string fromDate, string toDate);
        OperationResult GetTotalPaymentDetails(string fromDate, string toDate);
    }
}
