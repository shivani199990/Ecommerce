﻿using DriveSafe.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBContext
{
        public class DBContextClass : DbContext
        {
            public DBContextClass() : base("name=DefaultConnection") { }

            public DbSet<UserTable> userTable { get; set; }
        }
    }
}
