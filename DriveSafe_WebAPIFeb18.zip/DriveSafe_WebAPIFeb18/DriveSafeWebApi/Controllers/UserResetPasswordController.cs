﻿using DriveSafe.BussinessLayer;
using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/UserPasswordReset")]
    public class UserResetPasswordController : ApiController
    {
        /// <summary>
        /// UserManager Object reference
        /// </summary>
        private readonly IUserManager _userManager;
        /// <summary>
        /// constructor of current controller
        /// </summary>
        /// <param name="userManager"></param>
        public UserResetPasswordController(IUserManager userManager)
        {
            _userManager = userManager;
        }
        /// <summary>
        /// Change user Password
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UserPassword")]
        public async Task<OperationResult> ResetPassword([FromBody] ChangePassword  changePassword)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                var result = await _userManager.ResetPassword(changePassword);
                return result;
            }
        }
        /// <summary>
        /// Update new Password
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Update")]
        public async Task<OperationResult> UpdatePassword([FromBody] UserLogin userLogin)
        {
            if(!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                var result = await _userManager.UpdatePassword(userLogin);
                return result;
            }
        }
    }
}
