﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using DriveSafe.BussinessLayer;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AccessKeyVerifyController : ApiController
    {
        /// <summary>
        /// AdminManager object 
        /// </summary>
        private readonly IAdminManager _adminManager;

        /// <summary>
        /// AccessKey Constructor
        /// </summary>
        /// <param name="adminManager"></param>
        public AccessKeyVerifyController(IAdminManager adminManager)
        {
            _adminManager = adminManager;
        }

        /// <summary>
        /// Verifying AccessKey
        /// </summary>
        /// <param name="accessKey"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> VerifyAccessKey([FromBody] AccessKeyForAdmin accessKey)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                OperationResult result = await _adminManager.VerifyAccessKey(accessKey);
                return result;
            }
        }
    }
}
