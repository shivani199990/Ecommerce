﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class EventsController : ApiController
    {
        /// <summary>
        /// EventManager object
        /// </summary>
        private readonly IEventManager eventManager;
        /// <summary>
        /// AccessKey Constructor
        /// </summary>
        /// <param name="eventManager"></param>
        public EventsController(IEventManager eventManager)
        {
            this.eventManager = eventManager;
        }
        /// <summary>
        /// Verifying Events
        /// </summary>
        /// <param name="events"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> PostEventsDetails([FromBody] Events events)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await eventManager.PostEvents(events);
                return result;
            }
        }
        [HttpGet]
        public async Task<List<Events>> GetEventsDetails()
        {
            OperationResult result = await eventManager.GetEventsList();
            List<Events> list = (List<Events>)result.Data;
            return list;

        }
        [HttpPut]
        public async Task<OperationResult> UpdateEventsDetails(int id, Events events)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = "Invalid model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await eventManager.UpdateEvents(id, events);
                return result;
            }
        }
        [HttpDelete]
        public async Task<OperationResult> DeleteEventsDetails(int id)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = "Invalid model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await eventManager.Delete(id);
                return result;
            }
        }

    }
}
