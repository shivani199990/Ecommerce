﻿using DriveSafe.BussinessLayer;
using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Threading.Tasks;
using System.Threading;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*",headers: "*",methods: "*")]
    public class UserDetailsController : ApiController
    {
        /// <summary>
        /// instance of Bussiness layer through DI
        /// </summary>
        private readonly IUserManager _userManager;
        /// <summary>
        /// UserDetails constructor
        /// </summary>
        /// <param name="userManager"></param>
        public UserDetailsController(IUserManager userManager)
        {
            _userManager = userManager;
        }

        /// <summary>
        /// Storing User Sign-Up Details
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> PostUserDetails([FromBody] User user)
        {
            
            if(!ModelState.IsValid)
            {

                return new OperationResult()
                {
                    Message = (ModelState.Values
                    .SelectMany(v => v.Errors)
                     .First().ErrorMessage),    
                     Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                     
                }; 
            }
            else
            {
                return  await _userManager.SetUserDetails(user);
            }
        }


    }
}
