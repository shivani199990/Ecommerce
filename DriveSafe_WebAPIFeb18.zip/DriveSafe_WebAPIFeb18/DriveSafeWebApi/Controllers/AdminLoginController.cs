﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AdminLoginController : ApiController
    {
        /// <summary>
        /// AdminManager object
        /// </summary>
    
        readonly private IAdminManager _adminManager;

        /// <summary>
        /// AdminManager Constructor
        /// </summary>
        /// <param name="adminManager"></param>
        public AdminLoginController(IAdminManager adminManager)
        {
            _adminManager = adminManager;
        }

        /// <summary>
        /// Admin Login functionality
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> AdminLoginProcess([FromBody]AdminLogin adminLogin)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                OperationResult result = await _adminManager.StoreAdminLoginDetails(adminLogin);
                return result;
            }
        }
    }
}
