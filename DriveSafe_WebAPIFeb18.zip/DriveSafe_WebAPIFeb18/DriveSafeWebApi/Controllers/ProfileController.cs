﻿using DriveSafe.DataAccessLayer;
using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/Profile")]
    public class ProfileController : ApiController
    {
        private IProfileManager _profileManager;

        public ProfileController(IProfileManager _profileManager)
        {
            this._profileManager = _profileManager;
        }

        [HttpGet]
        [Route("UserProfile")]
        public async Task<OperationResult> GetUserProfile(string emailId)
        {
            if (!ModelState.IsValid)
            {

                return new OperationResult()
                {
                    Message = (ModelState.Values
                    .SelectMany(v => v.Errors)
                     .First().ErrorMessage),
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null

                };
            }
            else
            {
                return await _profileManager.GetUserProfile(emailId);
            }
        }
        [HttpGet]
        [Route("AdminProfile")]

        public async Task<OperationResult> GetAdminProfile(string emailId)

        {
            if (!ModelState.IsValid)
            {

                return new OperationResult()
                {
                    Message = (ModelState.Values
                    .SelectMany(v => v.Errors)
                     .First().ErrorMessage),
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null

                };
            }
            else
            {
                return await _profileManager.GetAdminProfile(emailId);
            }
        }
        
        [HttpPost]
        [Route("UpdateUser")]
        public async Task<OperationResult> UpdateUserProfile([FromBody] User user)
        {
                return await _profileManager.UpdateUserProfile(user);         
        }
        [HttpPost]
        [Route("UpdateAdmin")]
        public async Task<OperationResult> UpdateAdminProfile([FromBody] Admin admin)
        {
            
                var result = await _profileManager.UpdateAdminProfile(admin);
                return result;
            
        }
    }
}
