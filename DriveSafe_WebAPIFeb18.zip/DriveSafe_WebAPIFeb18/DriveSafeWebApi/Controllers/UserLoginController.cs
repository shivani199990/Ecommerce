﻿using DriveSafe.BussinessLayer;
using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Net.Mail;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class UserLoginController : ApiController
    {
        readonly private IUserManager _userManager;

        /// <summary>
        /// UserLogin constructor
        /// </summary>
        /// <param name="userManager"></param>
        public UserLoginController(IUserManager userManager)
        {
            _userManager = userManager;

        }
        /// <summary>
        /// Login Process functionality
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> PostLoginProcess(UserLogin userLogin)
        {

            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                var result = await _userManager.StoreUserLoginDetails(userLogin);
                return result;
            }
        }
    }
}
