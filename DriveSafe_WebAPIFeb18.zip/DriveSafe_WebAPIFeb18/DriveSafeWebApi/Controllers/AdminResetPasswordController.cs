﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/AdminPasswordReset")]
    public class AdminResetPasswordController : ApiController
    {
        /// <summary>
        /// AdminManager Object
        /// </summary>
        private readonly IAdminManager _adminManager;
        /// <summary>
        /// AdminResetPasswordController constructor
        /// </summary>
        /// <param name="adminManager"></param>
        public AdminResetPasswordController(IAdminManager adminManager)
        {
            _adminManager = adminManager;
        }
        /// <summary>
        /// Resetting password of admin
        /// </summary>
        /// <param name="adminManager"></param>
        [HttpPost]
        [Route("AdminPassword")]
        public async Task<OperationResult> ResetPassword([FromBody] ChangePassword changePassword)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                var result = await _adminManager.ResetPassword(changePassword);
                return result;
            }
        }
        /// <summary>
        /// Update Password after verification
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Update")]
        public async Task<OperationResult> UpdatePassword([FromBody] AdminLogin adminLogin)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                var result = await _adminManager.UpdatePassword(adminLogin);
                return result;
            }
        }
    }
}
