﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins:"*", methods:"*", headers:"*")]
    public class PaymentController : ApiController
    {
        private readonly IPaymentManager paymentManager;
        public PaymentController(IPaymentManager paymentManager)
        {
            this.paymentManager = paymentManager;
        }
        [HttpPost]
        public OperationResult Payment([FromBody] PaymentDetails paymentDetails)
        {
            if(!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                    return paymentManager.PayAmount(paymentDetails);
            }
        }

        [HttpGet]
        public OperationResult GetPaymentDetails(string fromDate, string toDate)
        {

            if(String.IsNullOrEmpty(fromDate) || String.IsNullOrEmpty(toDate))
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany( d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                return paymentManager.GetPaymentDetails(fromDate, toDate);
            }
        }
    }
}
