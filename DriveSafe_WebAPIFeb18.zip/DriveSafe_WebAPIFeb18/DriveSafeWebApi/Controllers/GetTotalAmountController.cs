﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins:"*", headers:"*", methods:"*")]
    public class GetTotalAmountController : ApiController
    {
       private IPaymentManager  _paymentManager;
        public GetTotalAmountController(IPaymentManager paymentManager)
        {
            _paymentManager = paymentManager;
        }

        [HttpGet]
        public OperationResult GetTotalPayment(string fromDate, string toDate)
        {
            return _paymentManager.GetTotalPaymentDetails(fromDate, toDate);
        }
    }
}
