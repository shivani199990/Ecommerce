﻿using DriveSafe.BussinessLayer;
using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AdminDetailsController : ApiController
    {
        /// <summary>
        /// AdminManager Object
        /// </summary>
        private readonly IAdminManager _adminManager;
        /// <summary>
        /// Admin Manager Constructor
        /// </summary>
        /// <param name="adminManager"></param>
        public AdminDetailsController(IAdminManager adminManager)
        {
            _adminManager = adminManager;
        }

        /// <summary>
        /// Storing Admin Sign-Up details
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<OperationResult> SetAdminDetails([FromBody] Admin admin)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                OperationResult result = await _adminManager.SetAdminDetails(admin);
                return result;
            }
        }
    }
}
