﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/News")]

    public class NewsFeedController : ApiController
    {
        private readonly INewsFeedManager newsManager;
        public NewsFeedController(INewsFeedManager newsManager)
        {
            this.newsManager = newsManager;
        }
        [HttpPost]
        [Route("PostNews")]

        public async Task<OperationResult> PostNewsDetails([FromBody] NewsFeed newsFeed)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await newsManager.PostNews(newsFeed);
                return result;
            }
        }
        [HttpGet]
        [Route("GetNews")]

        public async Task<List<NewsFeed>> GetNewsDetails()
        {
            OperationResult result = await newsManager.GetNewsList();
            List<NewsFeed> list = (List<NewsFeed>)result.Data;    
            return list;
           
        }
        [HttpPut]
        [Route("PutNews")]

        public async Task<OperationResult> UpdateNewsDetails(int id,NewsFeed newsFeed)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = "Invalid model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await newsManager.UpdateNews(id, newsFeed);
                return result;
            }
        }
        [HttpGet]
        [Route("DeleteNews")]

        public async Task<OperationResult> DeleteNewsDetails(int id)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = "Invalid model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await newsManager.DeleteNews(id);
                return result;
            }
        }

    }
}
