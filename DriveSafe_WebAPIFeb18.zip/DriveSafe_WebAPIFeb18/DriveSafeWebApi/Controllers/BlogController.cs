﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DriveSafeWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/Blog")]
    public class BlogController : ApiController
    {
        private readonly IBlogManager blogManager;
        public BlogController(IBlogManager blogManager)
        {
            this.blogManager = blogManager;
        }

        [HttpPost]
        [Route("Add")]
        public async Task<OperationResult> PostBlog([FromBody] Blogs blog)
        {
            if (!ModelState.IsValid)
            {
                return new OperationResult()
                {
                    Message = ModelState.Values.SelectMany(d => d.Errors).First().ErrorMessage,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound

                };
            }
            else
            {
                OperationResult result = await blogManager.PostBlog(blog);
                return result;
            }
        }

        [HttpGet]
        [Route("GetBlogForAdmin")]
        public async Task<List<Blogs>> GetBlog()
        {
            OperationResult result = await blogManager.GetBlog();
            List<Blogs> list = (List<Blogs>)result.Data;
            return list;

        }
        [HttpGet]
        [Route("GetBlogForUser")]
        public async Task<List<Blogs>> GetBlogForUser()
        {
            OperationResult result = await blogManager.GetBlogForUser();
            List<Blogs> list = (List<Blogs>)result.Data;
            return list;

        }

        [HttpPost]
        [Route("Reject")]
        public async Task<OperationResult> DeleteBlog([FromBody] Blogs blog)
        {
            if (blog == null)
            {
                return new OperationResult()
                {
                    Message = "Invalid BlogId",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }

            int blogId = blog.BlogId;

            if (blogId == 0)
            {
                return new OperationResult()
                {
                    Message = "Invalid Model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await blogManager.DeleteBlog(blogId);
                return result;
            }
        }

        [HttpPost]
        [Route("Approve")]
        public async Task<OperationResult> ApproveBlog([FromBody] Blogs blogs)
        {
            if (blogs == null)
            {
                return new OperationResult()
                {
                    Message = "Invalid BlogId",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }

            Blogs blog = new Blogs();

            int blogId = blogs.BlogId;

            if (blogId == 0)
            {
                return new OperationResult()
                {
                    Message = "Invalid Model state",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                OperationResult result = await blogManager.UpdateBlog(blogId, blog);
                return result;
            }
        }
    }
}
