
using DriveSafe.BussinessLayer;
using DriveSafe.DataAccessLayer;
using DriveSafe.DataAccessLayer.Repository;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace DriveSafeWebApi
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            container.RegisterType<IUserRepository, UserRepository>();
            container.RegisterType<IUserManager, UserManager>();
            container.RegisterType<IAdminRepository, AdminRepository>();
            container.RegisterType<IAdminManager, AdminManager>();
            container.RegisterType<IDBContex, DBContextClass>();
            container.RegisterType<INewsFeedManager, NewsManager>();
            container.RegisterType<INewsFeedRepository, NewsFeedRepository>();
            container.RegisterType<IEventManager, EventManager>();
            container.RegisterType<IEventsRepository, EventsRepository>();
            container.RegisterType<IBlogManager, BlogManager>();
            container.RegisterType<IBlogRepository, BlogRepository>();
            container.RegisterType<IPaymentManager, PaymentManager>();
            container.RegisterType<IPaymentRepository, PaymentRepository>();

            container.RegisterType<IProfileManager, ProfileManager>();
            container.RegisterType<IProfileRepository, ProfileRepository>();
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}