﻿using DriveSafe.DataAccessLayer;
using DriveSafe.DataAccessLayer.MockDataLayer;
using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{

    public class UserManager : IUserManager
    {
        /// <summary>
        /// reference of userrepository
        /// </summary>
        private readonly IUserRepository _userRepositorty;

        /// <summary>
        /// Constructor of UserManager
        /// </summary>
        /// <param name="userRepository"></param>
        public UserManager(IUserRepository userRepository)
        {
            _userRepositorty = userRepository;
        }


        /// <summary>
        /// GetUserDetails Return Details of A user
        /// </summary>
        /// <param name="user"></param>
        /// <returns>User</returns>
        public async Task<OperationResult> GetUserDetails(User user)
        {
            return new OperationResult()
            {
                Data = await _userRepositorty.GetUserDetails(user.EmailID)
            };
        }
        /// <summary>
        /// Storing User sign up data 
        /// </summary>
        /// <param name="user"></param>
        /// <returns>bool</returns>
        #region Store User SignUp Data
        public async Task<OperationResult> SetUserDetails(User user)
        {

            // check nullablity of parameter User 
            if(Object.ReferenceEquals(user, null) || String.IsNullOrEmpty(user.EmailID) || String.IsNullOrEmpty(user.Password))
            {
                return new OperationResult()
                {
                    Message = "User details should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                // fetch data of user from Database based on emailid 
                OperationResult result = await _userRepositorty.GetUserDetails(user.EmailID);
                //check nullablity of of userData
                if(result.Data == null)
                {
                    return await _userRepositorty.SetUserDetails(user);
                }
                else
                {
                    return new OperationResult()
                    {
                        Message = "User already exist",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    };
                }
            }
        }
        #endregion

        /// <summary>
        /// Storing user login details
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns>bool</returns>
        /// 

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(System.Text.Encoding.ASCII.GetBytes(userID + password));
        }
        private static bool MatchSHA1(byte[] p1, byte[] p2)
        {
            bool result = false;
            if (p1 != null && p2 != null)
            {
                if(p1.Length == p2.Length)
                {
                    result = true;
                    for (int i = 0; i < p1.Length; i++)
                    {
                        if (p1[i] != p2[i])
                        {
                            result = false;
                            break;
                        }
                    }
                }
            }
            return result;
        }

        #region
        public async Task<OperationResult> StoreUserLoginDetails(UserLogin userLogin)
        {
            // check nullablity of parameter User 
            if (userLogin == null ||  String.IsNullOrEmpty(userLogin.EmailId) || String.IsNullOrEmpty(userLogin.Password))
            {
                return new OperationResult()
                {
                    Message = "User emailId or password is empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                    // fetch data of user from Database based on emailid 
                    OperationResult result = await _userRepositorty.GetUserDetails(userLogin.EmailId);
                    // Invalid Email ID
                    if (result.Data==null)
                    {
                        return new OperationResult()
                        {
                            Message = "User does not exist",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound
                        };
                    }
                    else
                    {
                        User user = (User)result.Data;
                        // Valid user password
                        if(MatchSHA1(user.EncryptedPassword, GetSHA1(userLogin.EmailId.ToLower(), userLogin.Password)))
                        {
                            return await _userRepositorty.StoreUserLoginDetails(userLogin);
                        }
                        else
                        {
                        // Invalid user Password
                            return new OperationResult()
                            {
                                Message = "Incorrect password",
                                Status = false,
                                StatusCode = HttpStatusCode.NotFound
                            };
                        }
                    }
             }
        }
        #endregion
        /// <summary>
        /// Resetting password process verifying
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        #region
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            if(changePassword==null || String.IsNullOrWhiteSpace(changePassword.EmailId) || String.IsNullOrWhiteSpace(changePassword.PhoneNumber))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Message = "EmailId and Phone number can not be null",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
            else
            {
                Regex regex = new Regex(@"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$");
                Match match = regex.Match(changePassword.EmailId);
                if(!match.Success)
                {
                    return await Task.FromResult(new OperationResult()
                    {
                        Message = "EmailId is not valid",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
                }
                else
                {
                    OperationResult result = await _userRepositorty.ResetPassword(changePassword);
                    if(Object.ReferenceEquals(result, null))
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "EmailId or Phone number does not exist",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound
                        });
                    }
                    else
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "User can change password",
                            Status = true,
                            StatusCode = HttpStatusCode.OK
                        });
                    }
                }
            }
        }
        #endregion
        /// <summary>
        /// Updating Password
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns> 
        #region
        public async Task<OperationResult> UpdatePassword(UserLogin userLogin)
        {
            if (userLogin == null || String.IsNullOrWhiteSpace(userLogin.EmailId) || String.IsNullOrWhiteSpace(userLogin.Password))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Message = "EmailId and Password should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
            else
            {
                return await _userRepositorty.UpdatePassword(userLogin);
            }
        }
        #endregion
    }
}
