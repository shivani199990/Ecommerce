﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{
    public class EventManager : IEventManager
    {
        IEventsRepository eventsRepository;
        public EventManager(IEventsRepository eventsRepository)
        {
            this.eventsRepository = eventsRepository;
        }
        public Task<OperationResult> Delete(int id)
        {
            return eventsRepository.Delete(id);
        }

        public Task<OperationResult> GetEventsList()
        {
            return eventsRepository.GetEventsList();
        }

        public Task<OperationResult> PostEvents(Events events)
        {
            return eventsRepository.PostEvents(events);
        }

        public Task<OperationResult> UpdateEvents(int id, Events events)
        {
            return eventsRepository.UpdateEvents(id, events);


        }
    }
}
