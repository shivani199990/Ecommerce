﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{
    public class ProfileManager : IProfileManager
    {
        private readonly IProfileRepository _profileRepositorty;
        public ProfileManager(IProfileRepository _profileRepositorty)
        {
            this._profileRepositorty = _profileRepositorty;
        }
        public Task<OperationResult> GetAdminProfile(string emailId)
        {
            return _profileRepositorty.GetAdminProfile(emailId);
        }

        public Task<OperationResult> GetUserProfile(string emailId)
        {
            return _profileRepositorty.GetUserProfile(emailId);
        }
        
         public async Task<OperationResult> UpdateUserProfile(User user)
         {
            if(Object.ReferenceEquals(user, null) || String.IsNullOrEmpty(user.FirstName) || String.IsNullOrEmpty(user.LastName) || String.IsNullOrEmpty(user.PhoneNumber))
            {
                return new OperationResult()
                {
                    Message = "Manadatory fields should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                return  await _profileRepositorty.UpdateUserProfile(user);
            }
            
         }
        
        
        public async Task<OperationResult> UpdateAdminProfile(Admin admin)
        {
            if (Object.ReferenceEquals(admin, null) || String.IsNullOrEmpty(admin.FirstName) || String.IsNullOrEmpty(admin.LastName) || String.IsNullOrEmpty(admin.PhoneNumber))
            {
                return new OperationResult()
                {
                    Message = "Manadatory fields should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                return await _profileRepositorty.UpdateAdminProfile(admin);
            }
            
        }
    }
}
