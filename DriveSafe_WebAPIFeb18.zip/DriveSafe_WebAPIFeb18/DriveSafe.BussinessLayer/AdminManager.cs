﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using System.Web;
using System.Security.Cryptography;

namespace DriveSafe.BussinessLayer
{
    public class AdminManager : IAdminManager
    {
        /// <summary>
        /// AdminRepository Instance
        /// </summary>
        private readonly IAdminRepository _adminRepositorty;
        /// <summary>
        /// AdminManager Constructor
        /// </summary>
        /// <param name="adminRepository"></param>
        public AdminManager(IAdminRepository adminRepository)
        {
            _adminRepositorty = adminRepository;
        }

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(System.Text.Encoding.ASCII.GetBytes(userID + password));
        }
        private static bool MatchSHA1(byte[] p1, byte[] p2)
        {
            bool result = false;
            if (p1 != null && p2 != null)
            {
                if (p1.Length == p2.Length)
                {
                    result = true;
                    for (int i = 0; i < p1.Length; i++)
                    {
                        if (p1[i] != p2[i])
                        {
                            result = false;
                            break;
                        }
                    }
                }
            }
            return result;
        }
        /// <summary>
        /// getting Admindetails
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        #region  send admin details to frontend
        public async Task<OperationResult> GetAdminDetails(Admin admin)
        {
            return new OperationResult()
            {
                Data = await _adminRepositorty.GetAdminDetails(admin.EmailID)
            };
        }
        #endregion

        /// <summary>
        /// Storing Admin sign-up Details
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        /// 
        #region storing admin details
        public async Task<OperationResult> SetAdminDetails(Admin admin)
        {
            // check nullablity of parameter User
            if (Object.ReferenceEquals(admin, null) || String.IsNullOrEmpty(admin.EmailID))
            {
                return new OperationResult()
                {
                    Message = "Admin details can not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else
            {
                // fetch data of user from Database based on emailid 
                OperationResult result = await _adminRepositorty.GetAdminDetails(admin.EmailID);
                //check nullablity of of userData
                if (result.Data == null)
                {
                    return await _adminRepositorty.SetAdminDetails(admin);
                }
                else
                {
                    return new OperationResult()
                    {
                        Message = "Admin already exist",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    };
                }
            }
        }
        #endregion
        /// <summary>
        /// Storing Admin Login Details
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        /// 
        #region storig admin login details
        public async Task<OperationResult> StoreAdminLoginDetails(AdminLogin adminLogin)
        {
            // check nullablity of parameter User 
            if (Object.ReferenceEquals(adminLogin, null) || String.IsNullOrEmpty(adminLogin.EmailId) || String.IsNullOrEmpty(adminLogin.Password))
            {
                return new OperationResult()
                {
                    Message = "EmailId or password in empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                }; 
            }
            else
            {
                // fetch data of user from Database based on emailid 
                 OperationResult result = await _adminRepositorty.GetAdminDetails(adminLogin.EmailId);
                // Invalid Email ID
                if (result.Data == null)
                {
                    return new OperationResult()
                    {
                        Message = "Admin does not exist",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    };
                }
                else
                {
                    Admin admin = (Admin)result.Data;
                    // Valid user password
                    if (MatchSHA1(admin.EncryptedPassword, GetSHA1(adminLogin.EmailId.ToLower(), adminLogin.Password)))
                    {
                        return await _adminRepositorty.StoreAdminLoginDetails(adminLogin);
                    }
                    else
                    {
                        // Invalid user Password
                        return new OperationResult()
                        {
                            Message = "Incorrect password",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound
                        };
                    }
                }
            }
        }
        #endregion
        /// <summary>
        /// Verifying access key
        /// </summary>
        /// <param name="accessKey"></param>
        /// <returns></returns>
        #region verify Access Key
        public async Task<OperationResult> VerifyAccessKey(AccessKeyForAdmin accessKey)
        {
            if( Object.ReferenceEquals(accessKey, null) || String.IsNullOrWhiteSpace(accessKey.AccessKey))
            {
                return (new OperationResult()
                {
                    Message = "AccessKey value is Empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                });
            }
            else
            {
                Regex regex = new Regex(@"^[a-zA-Z0-9_]{1,15}$");
                Match match = regex.Match(accessKey.AccessKey);
                if(!match.Success)
                {
                    return (new OperationResult()
                    {
                        Message = "Access key should be alpha-numeric",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
                }
                else
                {
                    OperationResult result = await _adminRepositorty.VerifyAccessKey(accessKey.AccessKey);
                    AccessKeyForAdmin key = (AccessKeyForAdmin)result.Data;
                    if(String.IsNullOrEmpty(key.AccessKey))
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "Access Key does not exist in database",
                            Status = false,
                            StatusCode = HttpStatusCode.OK,
                        });
                    }
                    if (key.AccessKey.Equals(accessKey.AccessKey))
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "Admin Access key is Valid",
                            Status = true,
                            StatusCode = HttpStatusCode.OK,
                        });
                    }
                    else
                    {
                        return new OperationResult()
                        {
                            Message = "Incorrect Access key",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound
                        };
                    }
                }
            }
        }
        #endregion
        /// <summary>
        /// resetting password
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        #region Resetting Password
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            if (changePassword==null || String.IsNullOrWhiteSpace(changePassword.EmailId) || String.IsNullOrWhiteSpace(changePassword.PhoneNumber))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Message = "EmailId and Phone number can not be null",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
            else
            {
                Regex regex = new Regex(@"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$");
                Match match = regex.Match(changePassword.EmailId);
                if (!match.Success)
                {
                    return await Task.FromResult(new OperationResult()
                    {
                        Message = "EmailId is not valid",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
                }
                else
                {
                    OperationResult result = await _adminRepositorty.ResetPassword(changePassword);
                    if (Object.ReferenceEquals(result, null))
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "EmailId or Phone number does not exist",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound
                        });
                    }
                    else
                    {
                        return await Task.FromResult(new OperationResult()
                        {
                            Message = "Admin can change password",
                            Status = true,
                            StatusCode = HttpStatusCode.OK
                        });
                    }
                }
            }
        }
        #endregion
        /// <summary>
        /// Password update
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
#region password update
        public async Task<OperationResult> UpdatePassword(AdminLogin adminLogin)
        {
            if (adminLogin == null || String.IsNullOrWhiteSpace(adminLogin.EmailId) || String.IsNullOrWhiteSpace(adminLogin.Password))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Message = "EmailId and Password should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
            else
            {
                return await _adminRepositorty.UpdatePassword(adminLogin);
            }
        }
#endregion
    }
}
