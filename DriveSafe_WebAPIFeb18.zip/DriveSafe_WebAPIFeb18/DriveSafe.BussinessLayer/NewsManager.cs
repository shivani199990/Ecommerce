﻿using DriveSafe.IBussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;

namespace DriveSafe.BussinessLayer
{
    public class NewsManager : INewsFeedManager
    {
        INewsFeedRepository newsFeedRepository;
        public NewsManager(INewsFeedRepository newsFeedRepository)
        {
            this.newsFeedRepository = newsFeedRepository;
        }
        public Task<OperationResult> DeleteNews(int id)
        {
            return newsFeedRepository.Delete(id);
        }

        public Task<OperationResult> GetNewsList()
        {
            return newsFeedRepository.GetNewsList();
        }

        public Task<OperationResult> PostNews(NewsFeed newsFeed)
        {
            return newsFeedRepository.PostNewsFeed(newsFeed);
        }

        public Task<OperationResult> UpdateNews(int id, NewsFeed newsFeed)
        {
            return newsFeedRepository.UpdateNewsFeed(id, newsFeed);


        }
    }
}
