﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{
    public class PaymentManager : IPaymentManager
    {
        readonly private IPaymentRepository paymentRepository;
        public PaymentManager(IPaymentRepository paymentRepository)
        {
            this.paymentRepository = paymentRepository;
        }

        public OperationResult PayAmount(PaymentDetails paymentDetails)
        {
            if (Object.ReferenceEquals(paymentDetails, null) || paymentDetails.CardNumber == 0 || paymentDetails.CVV == 0 || paymentDetails.ExpiryMonth.Equals(null) || paymentDetails.ExpiryYear.Equals(null))
            {
                return new OperationResult()
                {
                    Message = "Card details should not empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                OperationResult result = paymentRepository.GetAccountHolderOfCard(paymentDetails);
                if(Object.ReferenceEquals(result, null) || (long)result.Data==0)
                {
                    return new OperationResult()
                    {
                        Message = "Invalid Card Details",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound,
                        Data = null
                    };
                }
                else
                {
                    bool status = paymentRepository.CheckBalance(paymentDetails.Amount, (long)result.Data).Status;
                    if(!status)
                    {
                        return new OperationResult()
                        {
                            Message = "Insufficient account balance",
                            Status = false,
                            StatusCode = HttpStatusCode.NotFound,
                            Data = null
                        };
                    }
                    else
                    {
                        OperationResult resultOfUpdate = paymentRepository.UpdateBalance((long)result.Data, paymentDetails.Amount);
                        status = resultOfUpdate.Status;
                        if(!status)
                        {
                            resultOfUpdate.Message = "Transaction failed" + "\n"+"Transaction Id:"+((TransactionHistoryTable)resultOfUpdate.Data).TransactionId.ToString();
                            resultOfUpdate.StatusCode = HttpStatusCode.NotFound;
                            return resultOfUpdate;
                        }
                        else
                        {
                            resultOfUpdate.Message = "Transaction completed successfully" +"\n"+ "Transaction Id:" + ((TransactionHistoryTable)resultOfUpdate.Data).TransactionId.ToString();
                            resultOfUpdate.StatusCode = HttpStatusCode.OK;
                            return resultOfUpdate;
                        }
                    }
                }
            }
        }

        public OperationResult GetPaymentDetails(string fromDate, string toDate)
        {
            if (string.IsNullOrEmpty(fromDate) || string.IsNullOrEmpty(toDate))
            {
                return new OperationResult()
                {
                    Message = "Date field should not be empty",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound,
                    Data = null
                };
            }
            else
            {
                return paymentRepository.GetPaymentDetails(fromDate, toDate);
            }
        }
        public OperationResult GetTotalPaymentDetails(string fromDate, string toDate)
        {
            return paymentRepository.GetTotalPaymentDetails(fromDate, toDate);
        }
    }
}
