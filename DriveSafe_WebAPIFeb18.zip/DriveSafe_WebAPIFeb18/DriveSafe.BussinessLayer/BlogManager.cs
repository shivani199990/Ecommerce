﻿using DriveSafe.Entities;
using DriveSafe.IBussinessLayer;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.BussinessLayer
{
    public class BlogManager : IBlogManager
    {
        readonly IBlogRepository blogRepository;

        public BlogManager(IBlogRepository blogRepository)
        {
            this.blogRepository = blogRepository;
        }
        public async Task<OperationResult> DeleteBlog(int BlogId)
        {
            return await blogRepository.DeleteBlog(BlogId);
        }

        public async Task<OperationResult> GetBlog()
        {
            return await blogRepository.GetBlog();
        }
        public async Task<OperationResult> GetBlogForUser()
        {
            return await blogRepository.GetBlogForUser();
        }

        public async Task<OperationResult> PostBlog(Blogs blogs)
        {
            return await blogRepository.PostBlog(blogs);
        }

        public async Task<OperationResult> UpdateBlog(int blogId, Blogs blogs)
        {
            return await blogRepository.UpdateBlog(blogId, blogs);
        }
    }
}
