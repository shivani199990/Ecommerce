﻿using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.MockDataLayer
{
     public class MockEventRepository : IEventsRepository
    {
        public async Task<OperationResult> PostEvents(Events events)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "Events details saved successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
        }

        public async Task<OperationResult> Delete(int id)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "Events Deleted Successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
        }

        public async Task<OperationResult> UpdateEvents(int id, Events events)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "Evets Updated Successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
        }

        public async Task<OperationResult> GetEventsList()
        {
            return await Task.FromResult
           (
                new OperationResult()
                {
                    Data = null,
                }
            );
        }
    }
}
