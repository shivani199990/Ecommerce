﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DriveSafe.Entities;
using System.Net;
using System.Security.Cryptography;

namespace DriveSafe.DataAccessLayer.MockDataLayer
{
    /// <summary>
    /// MockUserRepository has Implement IUserRepository
    /// </summary>
    public class MockUserRepository : IUserRepository
    {

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(Encoding.ASCII.GetBytes(userID + password));
        }
        private static bool MatchSHA1(byte[] p1, byte[] p2)
        {
            bool result = false;
            if (p1 != null && p2 != null)
            {
                if (p1.Length == p2.Length)
                {
                    result = true;
                    for (int i = 0; i < p1.Length; i++)
                    {
                        if (p1[i] != p2[i])
                        {
                            result = false;
                            break;
                        }
                    }
                }
            }
            return result;
        }
        /// <summary>
        /// GetUserDetails will fetch all data of a particular user
        /// </summary>
        /// <param name="EmailId"></param>
        /// <returns></returns>
        public async Task<OperationResult> GetUserDetails(String EmailId)
        {
            User user = new User() { EmailID = "amarjit.kumar@mindtree.com", FirstName = "Amarjit", LastName = "Kumar", DOB = "27/07/1994", Gender = "Male", PhoneNumber = "8147207280", Password = "asd123!@#", IsAdmin = 1, IsDeleted = false };
            if (user.EmailID.Equals(EmailId))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Data = user
                });
            }
            else
            {
                return new OperationResult()
                {
                    Data = null
                };
            }
        }

        /// <summary>
        /// Store user sign-up details in database
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<OperationResult> SetUserDetails(User user)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "User data inserted successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                   
                });
        }

        /// <summary>
        /// store data in database of userLogin
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> StoreUserLoginDetails(UserLogin userLogin)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "User Login Details stored",
                    Status = true,
                    StatusCode = HttpStatusCode.OK

                });
        }
        /// <summary>
        /// ResetPassword will verify emailId and Phone number 
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            UserTable userRow = new UserTable()
            {
                FirstName = "Amarjit",
                LastName = "Kumar",
                EmailID = "amarjit.kumar94@yahoo.com",
                PhoneNumber = "8147207280",
                DOB = "27/07/1994",
                Gender = "Male",
                EncryptedPassword = Encoding.ASCII.GetBytes("werty"),
                IsAdmin = 0,
                IsDeleted = false
            };
            if(userRow.EmailID.Equals(changePassword.EmailId) && userRow.PhoneNumber.Equals(changePassword.PhoneNumber))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Data = null
                });
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// UpdatePassword will update password after verification
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> UpdatePassword(UserLogin userLogin)
        {
            UserTable userRow = new UserTable()
            {
                FirstName = "Amarjit",
                LastName = "Kumar",
                EmailID = "amarjitkumar94@yahoo.com",
                DOB = "27/07/1994",
                Gender = "Male",
                EncryptedPassword= Encoding.ASCII.GetBytes("werty")
            };
            if (MatchSHA1(userRow.EncryptedPassword, GetSHA1(userLogin.EmailId ,userLogin.Password)))
            {
                userRow.EncryptedPassword = GetSHA1( userLogin.EmailId,userLogin.Password);
                return await Task.FromResult(new OperationResult()
                {
                    Message = "Password Updated",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            else
            {
                return (new OperationResult()
                {
                    Message = "Password could not be changed",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }
    }
}
