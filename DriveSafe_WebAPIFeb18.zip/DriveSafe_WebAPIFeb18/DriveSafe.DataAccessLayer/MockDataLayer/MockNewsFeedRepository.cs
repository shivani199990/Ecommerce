﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.MockDataLayer
{
    public class MockNewsFeedRepository : INewsFeedRepository
    {
        public async Task<OperationResult> PostNewsFeed(NewsFeed newsFeed)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "News details saved successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
        }

        public async Task<OperationResult> Delete(int id)
        {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Deleted Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
        }

        public async Task<OperationResult> UpdateNewsFeed(int id, NewsFeed newsFeed)
        {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Updated Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
        }

        public async Task<OperationResult> GetNewsList()
        {
            return await Task.FromResult
           (
                new OperationResult()
                {
                    Data = null,
                }
            );
        }
    }
}
