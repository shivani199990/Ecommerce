﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.MockDataLayer
{
    /// <summary>
    /// Implementing IAdminRepository Interface
    /// </summary>
    public class MockAdminRepository : IAdminRepository
    {
        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(Encoding.ASCII.GetBytes(userID + password));
        }
        private static bool MatchSHA1(byte[] p1, byte[] p2)
        {
            bool result = false;
            if (p1 != null && p2 != null)
            {
                if (p1.Length == p2.Length)
                {
                    result = true;
                    for (int i = 0; i < p1.Length; i++)
                    {
                        if (p1[i] != p2[i])
                        {
                            result = false;
                            break;
                        }
                    }
                }
            }
            return result;
        }
        /// <summary>
        /// GetAdminDetails will fetch all data of a particular Admin
        /// </summary>
        /// <param name="EmailId"></param>
        /// <returns>Task<OperationResult></returns>
        public async Task<OperationResult> GetAdminDetails(String EmailId)
        {
            Admin admin = new Admin() { EmailID = "amarjit.kumar@mindtree.com", FirstName = "Amarjit", LastName = "Kumar", DOB = "27/07/1994", Gender = "Male", PhoneNumber = "8147207280", Password = "asd123!@#"};
            if (admin.EmailID.Equals(EmailId))
            {
                return await Task.FromResult(new OperationResult()
                {
                    Data = admin
                });
            }
            else
            {
                return new OperationResult()
                {
                    Data = null
                };
            }
        }
        /// <summary>
        /// SetAdminDetails will store admin sign-up data in Database
        /// </summary>
        /// <param name="admin"></param>
        /// <returns>Task<OperationResult></returns>
        public async Task<OperationResult> SetAdminDetails(Admin admin)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "Admin data inserted successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK

                });
        }
        /// <summary>
        /// Storing Admin login detailsi admin login-audit
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns>Task<OperationResult></returns>
        public async Task<OperationResult> StoreAdminLoginDetails(AdminLogin adminLogin)
        {
            return await Task.FromResult(
                new OperationResult()
                {
                    Message = "Admin Login Details stored",
                    Status = true,
                    StatusCode = HttpStatusCode.OK

                });
        }
        /// <summary>
        /// ResetPassword will verify the existing emailId and phone number 
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns>Task<Result></returns>
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            return await Task.FromResult(new OperationResult()
            {
                Data = new Admin()
                {
                    FirstName = "Amarjit",
                    LastName = "Kumar",
                    EmailID = "amarjitkumar94@yahoo.com",
                    DOB = "27/07/1994",
                    Gender = "Male",
                    Password = "123!23",
                }
            });
        }

        /// <summary>
        /// Updatepassword will update password after verification of phonenumber and emailId
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> UpdatePassword(AdminLogin adminLogin)
        {
            AdminTable adminRow = new AdminTable()
            {
                FirstName = "Amarjit",
                LastName = "Kumar",
                EmailID = "amarjitkumar94@yahoo.com",
                DOB = "27/07/1994",
                Gender = "Male",
                EncryptedPassword = Encoding.ASCII.GetBytes("werty")
            };
            if(MatchSHA1(adminRow.EncryptedPassword, GetSHA1(adminLogin.EmailId, adminLogin.Password)))
            {
                adminRow.EncryptedPassword = GetSHA1(adminLogin.EmailId, adminLogin.Password); return await Task.FromResult(new OperationResult()
                {
                    Message = "Password Updated",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            else
            {
                return (new OperationResult()
                {
                    Message = "Password could not be changed",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }
        /// <summary>
        /// VerifyAccess key will verify access key entered
        /// </summary>
        /// <param name="accessKey"></param>
        /// <returns>Task<OperationResult></returns>
        public async Task<OperationResult> VerifyAccessKey(String accessKey)
        {
            AccessKeyForAdmin adminAccessKey = new AccessKeyForAdmin()
            {
                AccessKey = "asd123qwe2"
            };
            return await Task.FromResult(new OperationResult()
            {
                Data = adminAccessKey
            });
        }
    }
}
