namespace DriveSafe.DataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initialCreate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AdminTables", "EncryptedPassword", c => c.Binary());
            AddColumn("dbo.UserTables", "EncryptedPassword", c => c.Binary());
            DropColumn("dbo.AdminTables", "Password");
            DropColumn("dbo.UserTables", "Password");
        }
        
        public override void Down()
        {
            AddColumn("dbo.UserTables", "Password", c => c.String(nullable: false));
            AddColumn("dbo.AdminTables", "Password", c => c.String(nullable: false));
            DropColumn("dbo.UserTables", "EncryptedPassword");
            DropColumn("dbo.AdminTables", "EncryptedPassword");
        }
    }
}
