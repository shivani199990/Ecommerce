﻿using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer
{
    /// <summary>
    /// User Repository Class
    /// </summary>
    public class UserRepository : IUserRepository
    {
        /// <summary>
        /// reference of DBContext class
        /// </summary>
        readonly private IDBContex _dbContext;
        /// <summary>
        /// constructor of UserRepository class
        /// </summary>
        /// <param name="dbContext"></param>
        public UserRepository(IDBContex dbContext)
        {
            _dbContext = dbContext;
        }

        #region Get User Details
        /// <summary>
        /// Showing details
        /// </summary>
        /// <param name="EmailId"></param>
        /// <returns></returns>
        public async Task<OperationResult> GetUserDetails(String EmailId)
        {
            UserTable userRow;
            try
            {
                userRow = (from user in _dbContext.UserTable where user.EmailID.Equals(EmailId,StringComparison.CurrentCultureIgnoreCase) select user).FirstOrDefault();
                User userObject = new User()
                {
                    FirstName = userRow.FirstName,
                    LastName = userRow.LastName,
                    DOB = userRow.DOB,
                    Gender = userRow.Gender,
                    PhoneNumber = userRow.PhoneNumber,
                    EmailID = userRow.EmailID,
                    IsAdmin = userRow.IsAdmin,
                    IsDeleted = userRow.IsDeleted,
                    EncryptedPassword = userRow.EncryptedPassword
                };

                return await Task.FromResult(
                    new OperationResult()
                    {
                        Data = userObject
                    });
            }
            catch (Exception ex)
            {
                return new OperationResult()
                {
                    Data = null
                };
            }
        }
        #endregion

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(Encoding.ASCII.GetBytes(userID + password));
        }

        #region Storing User signUp details
        /// <summary>
        /// storing user sign-up details
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<OperationResult> SetUserDetails(User user)
        {
           

            try
            {
                UserTable userData = new UserTable()
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    DOB = Convert.ToDateTime(user.DOB).ToString("dd/MM/yyyy"),
                    Gender = user.Gender,
                    PhoneNumber = user.PhoneNumber,
                    EmailID = user.EmailID,
                    IsAdmin = user.IsAdmin,
                    IsDeleted = user.IsDeleted,
                    EncryptedPassword = GetSHA1(user.EmailID.ToLower(), user.Password)
                };
                _dbContext.UserTable.Add(userData);
                _dbContext.SaveChanges();
                return await Task.FromResult(new OperationResult()
                {
                    Message = "User Details saved successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            catch(Exception ex)
            {
                return new OperationResult()
                {
                    Message = ex.Message,
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                };
            }
        }
        #endregion

        public async Task<OperationResult> StoreUserLoginDetails(UserLogin userLogin)
        {
            UserLoginTable userLoginData = new UserLoginTable()
            {
                EmailId = userLogin.EmailId.ToLower(),
                LoginTime = DateTime.Now.ToString()
            };
            try
            {
                _dbContext.UserLoginTable.Add(userLoginData);
                _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "User loged-in successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception ex)
            {
                return (
                    new OperationResult()
                    {
                        Message = ex.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }

        #region Validation before updating password
        /// <summary>
        /// Resetting the Password
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            UserTable userRow;
            try
            {
                userRow = (from user in _dbContext.UserTable where user.EmailID.Equals(changePassword.EmailId, StringComparison.CurrentCultureIgnoreCase) && user.PhoneNumber.Equals(changePassword.PhoneNumber, StringComparison.CurrentCultureIgnoreCase) select user).FirstOrDefault();
                User userObject = new User()
                {
                    FirstName = userRow.FirstName,
                    LastName = userRow.LastName,
                    DOB = userRow.DOB,
                    Gender = userRow.Gender,
                    PhoneNumber = userRow.PhoneNumber,
                    EmailID = userRow.EmailID,
                    IsAdmin = userRow.IsAdmin,
                    IsDeleted = userRow.IsDeleted
                };
                OperationResult result = new OperationResult()
                {
                    Data = userObject
                };
                return await Task.FromResult(result);
            }
            catch(Exception ex)
            {
                return null;
            }
           
        }
        #endregion

        #region UpdatePassword
        /// <summary>
        /// Updating the User Password
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> UpdatePassword(UserLogin userLogin)
        {
            try
            {
                UserTable userRow = _dbContext.UserTable.Single(user => user.EmailID == userLogin.EmailId);
                userRow.EncryptedPassword = GetSHA1(userLogin.EmailId.ToLower(), userLogin.Password);
                _dbContext.SaveChanges();
                return await Task.FromResult(new OperationResult()
                {
                    Message = "Password Updated",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            catch (Exception ex)
            {
                return (new OperationResult()
                {
                    Message = "Password can not be changed",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }
#endregion
    }
}
