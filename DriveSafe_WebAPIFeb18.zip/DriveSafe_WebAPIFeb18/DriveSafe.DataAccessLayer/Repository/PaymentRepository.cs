﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.Repository
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly IDBContex dbContext;
        public PaymentRepository(IDBContex dbContext)
        {
            this.dbContext = dbContext;
        }
        public OperationResult GetAccountHolderOfCard(PaymentDetails paymentDetails)
        {
            try
            {
                long accountNumber = dbContext.CardDetailsTable.Where(card => card.CardNumber == paymentDetails.CardNumber &&
                                                                      card.CVV==paymentDetails.CVV &&
                                                                      card.ExpiryMonth.Equals(paymentDetails.ExpiryMonth) &&
                                                                      card.ExpiryYear.Equals(paymentDetails.ExpiryYear)).Select(card => card.AccountNumber).FirstOrDefault();
                return new OperationResult()
                {
                    Data = accountNumber
                };
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public OperationResult CheckBalance(decimal amount, long accountNumber)
        {
            decimal accountBalance = dbContext.BankAccountDetailsTable.Where(detail => detail.AccountNo == accountNumber).Select(data => data.Balance).First();
            if(accountBalance < amount)
            {
                return new OperationResult()
                {
                    Status = false
                };
            }
            else
            {
                return new OperationResult()
                {
                    Status = true
                };
            }
        }

        public OperationResult UpdateBalance(long accountNumber, decimal amount)
        {
            TransactionHistoryTable transactionTable = new TransactionHistoryTable()
            {
                TransactionDateAndTime = DateTime.Now.ToString(),
                PayeeAccountNumber = accountNumber,
                DraweeAccountNumber = 100430297280,
                Status = "Processing",
                AmountTransfered = amount
            };
            dbContext.TransactionTable.Add(transactionTable);
            dbContext.SaveChanges();

            try
            {
                BankAcountDetailsTable payeeAccountDetails = dbContext.BankAccountDetailsTable.Where(data => data.AccountNo == accountNumber).Select(data => data).First();
                BankAcountDetailsTable draweeAccountDetails = dbContext.BankAccountDetailsTable.Where(data => data.AccountNo == 100430297280).Select(data => data).First();

                payeeAccountDetails.Balance -= amount;
                draweeAccountDetails.Balance += amount;

                dbContext.SaveChanges();

                transactionTable.Status = "Success";
                dbContext.SaveChanges();

                return new OperationResult()
                {
                    Status = true,
                    Data = transactionTable
                };
            }
            catch(Exception ex)
            {
                transactionTable.Status = "Failed";
                dbContext.SaveChanges();
                return new OperationResult()
                {
                    Status = false,
                    Data = transactionTable
                };
            }
        }

        public OperationResult GetPaymentDetails(string fromDate, string toDate)
        {

            
            try
            {
                DateTime frmDateConverted = Convert.ToDateTime(fromDate);
                var frmDate = frmDateConverted.Date;
                DateTime toDateConverted = Convert.ToDateTime(toDate);
                var tDate = toDateConverted.Date;
                TimeSpan difference = tDate.Date - frmDate.Date;
                int days = (int)difference.TotalDays;
                if (days >= 0)
                {
                    List<TransactionHistoryTable> transactionData1 = dbContext.TransactionTable.ToList();
                    List<TransactionHistoryTable> transactionData2 = transactionData1.Where(data =>
                                            (DateTime.Compare(Convert.ToDateTime(data.TransactionDateAndTime).Date, frmDate)) >= 0 &&
                                                (DateTime.Compare(Convert.ToDateTime(data.TransactionDateAndTime).Date, tDate)) <= 0).ToList();
                    return new OperationResult()
                    {
                        Message = "Data Fetched successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK,
                        Data = transactionData2
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Status = false,
                        Data = null
                    };
                }
            }
            catch(Exception ex)
            {
                return new OperationResult()
                {
                    Message = "No data exist",
                    Status = false,
                    Data = null
                };
            }
        }
        public OperationResult GetTotalPaymentDetails(string fromDate, string toDate)
        {


            try
            {
                DateTime frmDateConverted = Convert.ToDateTime(fromDate);
                var frmDate = frmDateConverted.Date;
                DateTime toDateConverted = Convert.ToDateTime(toDate);
                var tDate = toDateConverted.Date;
                List<TransactionHistoryTable> transactionData1 = dbContext.TransactionTable.ToList();
                decimal totalAmount = transactionData1.Sum(data => data.AmountTransfered);

                List<TransactionHistoryTable> transactionData2 = transactionData1.Where(data =>
                                        (DateTime.Compare(Convert.ToDateTime(data.TransactionDateAndTime).Date, frmDate)) >= 0 &&
                                            (DateTime.Compare(Convert.ToDateTime(data.TransactionDateAndTime).Date, tDate)) <= 0).ToList();
                decimal frmToAmount = transactionData2.Sum(data => data.AmountTransfered);
                List<Decimal> amount = new List<decimal>();
                amount.Add(totalAmount);
                amount.Add(frmToAmount);
                return new OperationResult()
                {
                    Message = "Data Fetched successfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK,
                    Data = amount
                };
            }
            catch (Exception ex)
            {
                return new OperationResult()
                {
                    Message = "No data exist",
                    Status = false,
                    Data = null
                };
            }
        }
    }
}
