﻿using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DriveSafe.Entities;
using System.Net;
using System.Security.Cryptography;

namespace DriveSafe.DataAccessLayer.Repository
{
    public class ProfileRepository : IProfileRepository
    {
        /// <summary>
        /// reference of DBContext Class
        /// </summary>
        readonly private IDBContex _dbContext;
        public ProfileRepository(IDBContex dbContext)
        {
            _dbContext = dbContext;
        }

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(Encoding.ASCII.GetBytes(userID + password));
        }
        public async Task<OperationResult> GetAdminProfile(string EmailId)
        {
            AdminTable adminRow;
            try
            {
                adminRow = (from admin in _dbContext.AdminTable where admin.EmailID.Equals(EmailId, StringComparison.CurrentCultureIgnoreCase) select admin).First();

            }
            catch (Exception)
            {
                return new OperationResult()
                {
                    Data = null
                };
            }

            Admin adminObject = new Admin()
            {
                FirstName = adminRow.FirstName,
                LastName = adminRow.LastName,
                DOB = adminRow.DOB,
                Gender = adminRow.Gender,
                PhoneNumber = adminRow.PhoneNumber,
                EmailID = adminRow.EmailID,
            };

            return await Task.FromResult(
                new OperationResult()
                {
                    Data = adminObject
                }
                );
        }

        public async Task<OperationResult> GetUserProfile(string EmailId)
        {
            UserTable userRow;
            try
            {
                userRow = (from user in _dbContext.UserTable where user.EmailID.Equals(EmailId, StringComparison.CurrentCultureIgnoreCase) select user).FirstOrDefault();
               
                User userObject = new User()
                {
                    FirstName = userRow.FirstName,
                    LastName = userRow.LastName,
                    DOB = userRow.DOB,
                    Gender = userRow.Gender,
                    PhoneNumber = userRow.PhoneNumber,
                    EmailID = userRow.EmailID,
                    IsAdmin = userRow.IsAdmin,
                    IsDeleted = userRow.IsDeleted
                };

                return await Task.FromResult(
                    new OperationResult()
                    {
                        Data = userObject
                    });
            }
            catch (Exception ex)
            {
                return new OperationResult()
                {
                    Data = null
                };
            }
        }

        public async Task<OperationResult> UpdateUserProfile(User user)
        {
            try
            {
                UserTable userRow = _dbContext.UserTable.Single(userDetail => userDetail.EmailID == user.EmailID);
                userRow.FirstName = user.FirstName;
                userRow.LastName = user.LastName;
                userRow.PhoneNumber = user.PhoneNumber;
                if (!String.IsNullOrEmpty(user.Password))
                {
                    userRow.EncryptedPassword = GetSHA1(user.EmailID, user.Password);
                }
                _dbContext.SaveChanges();
                return await Task.FromResult(new OperationResult()
                {
                    Message = "Profile Updated Sucessfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            catch (Exception ex)
            {
                return (new OperationResult()
                {
                    Message = "Profile can not be updated",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }

        public async Task<OperationResult> UpdateAdminProfile(Admin admin)
        {
            try
            {
                AdminTable adminRow = _dbContext.AdminTable.Single(adminDetail => adminDetail.EmailID == admin.EmailID);
                adminRow.FirstName = admin.FirstName;
                adminRow.LastName = admin.LastName;
                adminRow.PhoneNumber = admin.PhoneNumber;
                if (!String.IsNullOrEmpty(admin.Password))
                {
                    adminRow.EncryptedPassword = GetSHA1(admin.EmailID, admin.Password);
                }
                _dbContext.SaveChanges();
                return await Task.FromResult(new OperationResult()
                {
                    Message = "Profile Updated Sucessfully",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            catch (Exception ex)
            {
                return (new OperationResult()
                {
                    Message = "Profile can not be updated",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }

    }
}
