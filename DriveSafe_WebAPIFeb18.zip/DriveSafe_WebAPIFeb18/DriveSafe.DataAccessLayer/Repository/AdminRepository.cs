﻿using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer
{
    /// <summary>
    /// AdminRepository has implement IAdminRepository
    /// </summary>
    public class AdminRepository : IAdminRepository
    {
        /// <summary>
        /// reference of DBContext Class
        /// </summary>
        readonly private IDBContex _dbContext;

        public AdminRepository(IDBContex dbContext)
        {
            _dbContext = dbContext;
        }

        private static byte[] GetSHA1(string userID, string password)
        {
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            return sha.ComputeHash(Encoding.ASCII.GetBytes(userID + password));
        }

        /// <summary>
        /// GetAdmindetails will fetch all data of a particular admin
        /// </summary>
        /// <param name="EmailId"></param>
        /// <returns></returns>
        public async Task<OperationResult> GetAdminDetails(String EmailId)
        {
            AdminTable adminRow;
            try
            {
                adminRow = (from admin in _dbContext.AdminTable where admin.EmailID.Equals(EmailId, StringComparison.CurrentCultureIgnoreCase) select admin).First();

            }
            catch (Exception)
            {
                return new OperationResult()
                {
                    Data = null
                };
            }
            Admin adminObject = new Admin()
            {
                FirstName = adminRow.FirstName,
                LastName = adminRow.LastName,
                DOB = adminRow.DOB,
                Gender = adminRow.Gender,
                PhoneNumber = adminRow.PhoneNumber,
                EmailID = adminRow.EmailID,
                EncryptedPassword = adminRow.EncryptedPassword
            };

            return await Task.FromResult(
                new OperationResult()
                {
                    Data = adminObject
                }
                );
        }
        /// <summary>
        /// SetAdminDetails will store admin login to data base 
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        public async Task<OperationResult> SetAdminDetails(Admin admin)
        {
            AdminTable adminData = new AdminTable()
            {
                FirstName = admin.FirstName,
                LastName = admin.LastName,
                DOB = Convert.ToDateTime(admin.DOB).ToString("dd/MM/yyyy"),
                Gender = admin.Gender,
                PhoneNumber = admin.PhoneNumber,
                EmailID = admin.EmailID.ToLower(),
                EncryptedPassword = GetSHA1(admin.EmailID.ToLower(), admin.Password)
            };

            try
            {
                _dbContext.AdminTable.Add(adminData);
                _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Admin details saved successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception ex)
            {
                return (
                    new OperationResult()
                    {
                        Message = ex.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }

        /// <summary>
        /// StoreAdminLoginDetails will store adminlogin details in database
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> StoreAdminLoginDetails(AdminLogin adminLogin)
        {
            AdminLoginTable adminLoginData = new AdminLoginTable()
            {
                EmailId = adminLogin.EmailId.ToLower(),
                LoginTime = DateTime.Now.ToString()
            };
            try
            {
                _dbContext.AdminLoginTable.Add(adminLoginData);
                _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Admin loged-in successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception ex)
            {
                return (
                    new OperationResult()
                    {
                        Message = ex.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }

        /// <summary>
        /// verify acccesskey will verify existing accesskey present in database
        /// </summary>
        /// <param name="accessKey"></param>
        /// <returns></returns>
        public async Task<OperationResult> VerifyAccessKey(String accessKey)
        {
            string key = (from adminAccessKey in _dbContext.AdminAccessKey select adminAccessKey.AccessKey).SingleOrDefault();
            return await Task.FromResult(new OperationResult()
            {
                Data = new AccessKeyForAdmin() { AccessKey = key }
            });
        }

        /// <summary>
        /// resetpassword will verify the entered emailId and phone number
        /// </summary>
        /// <param name="changePassword"></param>
        /// <returns></returns>
        public async Task<OperationResult> ResetPassword(ChangePassword changePassword)
        {
            AdminTable adminRow;
            try
            {
                adminRow = (from admin in _dbContext.AdminTable where admin.EmailID.Equals(changePassword.EmailId, StringComparison.CurrentCultureIgnoreCase) && admin.PhoneNumber.Equals(changePassword.PhoneNumber, StringComparison.CurrentCultureIgnoreCase) select admin).First();
                Admin adminObject = new Admin()
                {
                    FirstName = adminRow.FirstName,
                    LastName = adminRow.LastName,
                    DOB = adminRow.DOB,
                    Gender = adminRow.Gender,
                    PhoneNumber = adminRow.PhoneNumber,
                    EmailID = adminRow.EmailID,
                };
                OperationResult result = new OperationResult()
                {
                    Data = adminObject
                };
                return await Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return null;
            }
            
        }

        /// <summary>
        /// UpdatePassword will update password if verification is done
        /// </summary>
        /// <param name="adminLogin"></param>
        /// <returns></returns>
        public async Task<OperationResult> UpdatePassword(AdminLogin adminLogin)
        {
            try
            {
                AdminTable adminRow = _dbContext.AdminTable.Single(admin => admin.EmailID == adminLogin.EmailId);
                adminRow.EncryptedPassword = GetSHA1(adminLogin.EmailId.ToLower(), adminLogin.Password);
                _dbContext.SaveChanges();
                return await Task.FromResult(new OperationResult()
                {
                    Message = "Password Updated",
                    Status = true,
                    StatusCode = HttpStatusCode.OK
                });
            }
            catch(Exception ex)
            {
                return (new OperationResult()
                {
                    Message = "Password could not be changed",
                    Status = false,
                    StatusCode = HttpStatusCode.NotFound
                });
            }
        }
    }
}
