﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.Repository
{
    public class EventsRepository: IEventsRepository
    {
        readonly private IDBContex _dbContext;

        public EventsRepository(IDBContex dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<OperationResult> PostEvents(Events events)
        {
            EventsTable eventsTable = new EventsTable()
            {
                EventName = events.EventName,
                Venue = events.Venue,
                Date = events.Date,
                Time = events.Time,
                Description = events.Description,
                EmailId = events.EmailId

            };
            try
            {
                _dbContext.eventsTable.Add(eventsTable);
                int rowsUpdated = _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Events details saved successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }

        }
        public async Task<OperationResult> Delete(int id)
        {
            int rowsUpdated;
            try
            {
                EventsTable events = _dbContext.eventsTable.Find(id);
                _dbContext.eventsTable.Remove(events);
                rowsUpdated = _dbContext.SaveChanges();
            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }

            if (rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Events Deleted Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Events Deletion Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }
        public async Task<OperationResult> UpdateEvents(int id, Events events)
        {
            int rowsUpdated;
            EventsTable eventsTable = new EventsTable()
            {
                EventName = events.EventName,
                Venue = events.Venue,
                Date = events.Date,
                Time = events.Time,
                Description = events.Description,
                EmailId = events.EmailId

            };
            try
            {
                EventsTable eventTbl = _dbContext.eventsTable.Find(id);
                eventTbl.EventName = events.EventName;
                eventTbl.Venue = events.Venue;
                eventTbl.Date = events.Date;
                eventTbl.Time = events.Time;
                eventTbl.Description = events.Description;
                eventTbl.EmailId = events.EmailId;
                rowsUpdated = _dbContext.SaveChanges();
            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = "Events Deletion Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }

            if (rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Events Updated Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Events Updation Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }
        public async Task<OperationResult> GetEventsList()
        {
            List<EventsTable> eventsTableList = _dbContext.eventsTable.ToList();
            List<Events> eventsList = new List<Events>();
            foreach (EventsTable eventTbl in eventsTableList)
            {
                Events events = new Events()
                {
                    EventName = eventTbl.EventName,
                    Venue = eventTbl.Venue,
                    Date = eventTbl.Date,
                    Time = eventTbl.Time,
                    Description = eventTbl.Description,
                    EmailId = eventTbl.EmailId,
                    Id = eventTbl.Id
                };
                eventsList.Add(events);
            }

            return await Task.FromResult
           (
                new OperationResult()
                {
                    Data = eventsList,
                }
            );
        }
    }
}
