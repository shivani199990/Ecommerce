﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.Repository
{
    public class NewsFeedRepository : INewsFeedRepository
    {
        readonly private IDBContex _dbContext;

        public NewsFeedRepository(IDBContex dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<OperationResult> PostNewsFeed(NewsFeed newsFeed)
        {
            NewsFeedTable newsFeedTable = new NewsFeedTable()
            {
                HeadLines = newsFeed.HeadLines,
                Description = newsFeed.Description,
                Link = newsFeed.Link
            };
            try
            {
                _dbContext.newsFeedTable.Add(newsFeedTable);
                int rowsUpdated = _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News details saved successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception exception)
            {
                return(
                    new OperationResult()
                    { 
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
 
        }
        public async Task<OperationResult> Delete(int id)
        {
            int rowsUpdated;
            try
            {
                NewsFeedTable newsFeed = _dbContext.newsFeedTable.Find(id);
                _dbContext.newsFeedTable.Remove(newsFeed);
                rowsUpdated = _dbContext.SaveChanges();
            }
            catch(Exception exception)
            {
                return(
                    new OperationResult()
                    {
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
            
            if (rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Deleted Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Deletion Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }
        public async Task<OperationResult>  UpdateNewsFeed(int id, NewsFeed newsFeed)
        {
            int rowsUpdated;
            NewsFeedTable newsFeedTable = new NewsFeedTable()
            {
                HeadLines = newsFeed.HeadLines,
                Description = newsFeed.Description,
                Link = newsFeed.Link
            };
            try
            {
                NewsFeedTable news = _dbContext.newsFeedTable.Find(id);
                news.HeadLines = newsFeed.HeadLines;
                news.Description = newsFeed.Description;
                news.Link = newsFeed.Link;
                rowsUpdated = _dbContext.SaveChanges();
            }
            catch(Exception exception)
            {
                return(
                    new OperationResult()
                    {
                        Message = "News Deletion Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
            
            if(rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Updated Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "News Updation Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }
        public async Task<OperationResult> GetNewsList()
        {
            List<NewsFeedTable> newsTableList= _dbContext.newsFeedTable.ToList();
            List<NewsFeed> newsList = new List<NewsFeed>();
            foreach(NewsFeedTable news in newsTableList)
            {
                NewsFeed newsFeed = new NewsFeed()
                {
                    HeadLines = news.HeadLines,
                    Description = news.Description,
                    Link = news.Link,
                    Id = news.id
                };
                newsList.Add(newsFeed);
            }
            newsList.Reverse();
            return await Task.FromResult
           (
                new OperationResult()
                {
                    Data = newsList,
                }
            );
        }
    }
}
