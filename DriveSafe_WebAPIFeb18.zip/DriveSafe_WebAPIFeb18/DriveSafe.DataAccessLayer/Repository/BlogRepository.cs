﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.Entities;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.Repository
{
    public class BlogRepository : IBlogRepository
    {
        readonly private IDBContex _dbContext;

        public BlogRepository(IDBContex dBContext)
        {
            _dbContext = dBContext;
        }
        public async Task<OperationResult> GetBlog()
        {
            // List<BlogTable> blogTableList = _dbContext.BlogTable.ToList();
            
            List < BlogTable > blogTableList = (from p in _dbContext.BlogTable where p.IsApproval == false select p).ToList();
            List<Blogs> blogList = new List<Blogs>();
            foreach (BlogTable blogit in blogTableList)
            {
                Blogs blog = new Blogs()
                {
                    BlogId = blogit.BlogId,
                    BlogTitle = blogit.BlogTitle,
                    BlogContent = blogit.BlogContent,
                    BlogDateTime = blogit.BlogDateTime.ToString(),
                    IsApproval = blogit.IsApproval,
                    IsDelete = blogit.IsDelete,
                    UserEmail = blogit.UserEmail
                };
                blogList.Add(blog);
            }

            return await Task.FromResult
           (
                new OperationResult()
                {
                    Data = blogList,
                }
            );
        }

        public async Task<OperationResult> GetBlogForUser()
        {
            // List<BlogTable> blogTableList = _dbContext.BlogTable.ToList();
            List<BlogTable> blogTableList = (from p in _dbContext.BlogTable where p.IsApproval == true select p).ToList();
            List<Blogs> blogList = new List<Blogs>();
            foreach (BlogTable blogit in blogTableList)
            {
                Blogs blog = new Blogs()
                {
                    BlogId = blogit.BlogId,
                    BlogTitle = blogit.BlogTitle,
                    BlogContent = blogit.BlogContent,
                    BlogDateTime = blogit.BlogDateTime.ToString(),
                    IsApproval = blogit.IsApproval,
                    IsDelete = blogit.IsDelete,
                    UserEmail = blogit.UserEmail

                };
                blogList.Add(blog);
            }
            blogList.Reverse();
            return await Task.FromResult
           (
                
                new OperationResult()
                {
                    Data = blogList,
                }
            );
        }

        public async Task<OperationResult> PostBlog(Blogs blog)
        {
            DateTime utcTime = DateTime.Now;
            TimeZoneInfo indianTime = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime convertedTime = TimeZoneInfo.ConvertTime(utcTime, indianTime);

            BlogTable blogTable = new BlogTable()
            {
                BlogTitle = blog.BlogTitle,
                BlogContent = blog.BlogContent,
                BlogDateTime = convertedTime,
                UserEmail = blog.UserEmail,
                IsApproval = false,
                IsDelete = false

            };
            try
            {
                _dbContext.BlogTable.Add(blogTable);
                int rowsUpdated = _dbContext.SaveChanges();
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Blog Successfully Sent To Admin For Aproval...!!",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });


            }
        }
        public async Task<OperationResult> DeleteBlog(int BlogId)
        {
            int rowsUpdated;
            try
            {
                BlogTable blog = _dbContext.BlogTable.Find(BlogId);
                _dbContext.BlogTable.Remove(blog);
                rowsUpdated = _dbContext.SaveChanges();

            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = exception.Message,
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    }
                );
            }
            if (rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Blogs Rejected Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Blogs Rejected Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }


        }








        public async Task<OperationResult> UpdateBlog(int id, Blogs blog)
        {
            int rowsUpdated;
            try
            {
                BlogTable blogTable = _dbContext.BlogTable.Find(id);
                blogTable.IsApproval = true;

                rowsUpdated = _dbContext.SaveChanges();
            }
            catch (Exception exception)
            {
                return (
                    new OperationResult()
                    {
                        Message = "Blog Approve Failed",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
            if (rowsUpdated > 0)
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Blogs Approved Successfully",
                        Status = true,
                        StatusCode = HttpStatusCode.OK
                    });
            }
            else
            {
                return await Task.FromResult(
                    new OperationResult()
                    {
                        Message = "Blogs Approval Failed .!",
                        Status = false,
                        StatusCode = HttpStatusCode.NotFound
                    });
            }
        }

        public async Task<OperationResult> PutBlog()
        {
            throw new NotSupportedException();
        }

    }
}
