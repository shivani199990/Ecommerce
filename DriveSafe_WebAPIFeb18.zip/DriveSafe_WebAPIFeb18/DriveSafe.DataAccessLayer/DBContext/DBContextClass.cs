﻿using DriveSafe.DataAccessLayer.TableRefereces;
using DriveSafe.IDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer
{
        public class DBContextClass : DbContext, IDBContex
        {
            public DBContextClass() : base("name=DefaultConnection")
            {

            }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<UserLoginTable>().ToTable("UserLoginTable");
        }
            public DbSet<UserTable> UserTable { get; set; }
            public DbSet<AdminTable> AdminTable { get; set; }
            public DbSet<UserLoginTable> UserLoginTable { get; set; }
            public DbSet<AdminLoginTable> AdminLoginTable { get; set; }
            public DbSet<AdminAccessKey> AdminAccessKey { get; set; }
            public DbSet<NewsFeedTable> newsFeedTable { get; set; }
            public DbSet<EventsTable> eventsTable { get; set; }
            
            public DbSet<BlogTable> BlogTable { get; set; }
            public DbSet<CardDetailsTable> CardDetailsTable { get; set; }
            public DbSet<BankAcountDetailsTable> BankAccountDetailsTable { get; set; }
            public DbSet<TransactionHistoryTable> TransactionTable { get; set; }
    }
}
