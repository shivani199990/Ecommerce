﻿using DriveSafe.DataAccessLayer;
using DriveSafe.DataAccessLayer.TableRefereces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IDBContex : IDisposable
    {
        DbSet<UserTable> UserTable { get; set; }
        DbSet<AdminTable> AdminTable { get; set; }
        DbSet<UserLoginTable> UserLoginTable { get; set; }
        DbSet<AdminLoginTable> AdminLoginTable { get; set; }
        DbSet<AdminAccessKey> AdminAccessKey { get; set; }
        DbSet<NewsFeedTable> newsFeedTable { get; set; }
        DbSet<BlogTable> BlogTable { get; set; }
        DbSet<CardDetailsTable> CardDetailsTable { get; set; }
        DbSet<BankAcountDetailsTable> BankAccountDetailsTable { get; set; }
        DbSet<TransactionHistoryTable> TransactionTable { get; set; }
        DbSet<EventsTable> eventsTable { get; set; }
       


        int SaveChanges();
    }
}
