﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    public class BankAcountDetailsTable
    {
        [Key]
        [Required]
        public long AccountNo { get; set; }
        public string UserId { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailId { get; set; }
        public decimal Balance { get; set; }
    }
}
