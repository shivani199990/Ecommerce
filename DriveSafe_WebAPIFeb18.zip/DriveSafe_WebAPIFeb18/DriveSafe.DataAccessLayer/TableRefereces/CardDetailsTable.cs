﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    public class CardDetailsTable
    {
        [Key]
        [Required]
        public long CardNumber { get; set; }
        public string ExpiryMonth { get; set; }
        public string ExpiryYear { get; set; }
        public int CVV { get; set; }

        [ForeignKey("BankAccountDetails")]
        public long AccountNumber { get; set; }
        public BankAcountDetailsTable BankAccountDetails { get; set; }
    }
}
