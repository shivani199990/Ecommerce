﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    public class AdminAccessKey
    {
        /// <summary>
        /// Get and set AccessKey
        /// </summary>
        [Key]
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_]{1,15}$", ErrorMessage = "Invalid Email-Id")]
        public string AccessKey { get; set; }
    }
}
