﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer
{
    public class UserTable
    {
        /// <summary>
        /// get and set Firstname of user
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage="FirstName should not be empty")]
        [StringLength(20)]
        public string FirstName { get; set; }

        /// <summary>
        /// get and set last anme
        /// </summary>
        [StringLength(20)]
        public string LastName  { get; set; }
        /// <summary>
        /// get and set Gender
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "Gender should not be empty")]
        public string Gender    { get; set; }
        /// <summary>
        /// get and set DOB
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "Date Of Birth should not be empty")]
        public string DOB       { get; set; }
        /// <summary>
        /// get and set phonenumber
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "Phone should not be empty")]
        [DataType(DataType.PhoneNumber, ErrorMessage ="Invalid Phone Number")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// get and set email id
        /// </summary>
        [Key]
        [Required(AllowEmptyStrings = false, ErrorMessage = "EmailID should not be empty")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$", ErrorMessage = "E-mail is not valid")]
        public string EmailID { get; set; }

        /// <summary>
        /// get and set IsAdmin
        /// </summary>
        public int IsAdmin { get; set; }

        /// <summary>
        /// get and set is deleted
        /// </summary>
        public bool IsDeleted { get; set; }
        public byte[] EncryptedPassword { get; set; }
    } 
}
