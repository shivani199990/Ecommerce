﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    [Table("tblBlog")]
    public class BlogTable
    {
        [Key]
        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public int BlogId { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string BlogTitle { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string BlogContent { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public DateTime BlogDateTime { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string UserEmail { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public bool IsApproval { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public bool IsDelete { get; set; }



    }
}
