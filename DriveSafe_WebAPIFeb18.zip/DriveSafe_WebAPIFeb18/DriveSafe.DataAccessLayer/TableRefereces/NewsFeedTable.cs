﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    [Table("tblNewsFeed")]
    public class NewsFeedTable
    {
        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string HeadLines { get; set; }
        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string Description { get; set; }
        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string Link { get; set; }
        [Key]
        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public int id { get; set; }
    }
}
