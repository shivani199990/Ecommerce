﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer.TableRefereces
{
    public class TransactionHistoryTable
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TransactionId { get; set; }
        public long PayeeAccountNumber { get; set; }
        public long DraweeAccountNumber { get; set; }
        public string TransactionDateAndTime { get; set; }
        public string Status { get; set; }
        public decimal AmountTransfered { get; set; }
    }
}
