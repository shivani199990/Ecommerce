﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface INewsFeedRepository
    {
        Task<OperationResult> PostNewsFeed(NewsFeed newsFeed);
        Task<OperationResult> Delete(int id);
        Task<OperationResult> UpdateNewsFeed(int id, NewsFeed newsFeed);
        Task<OperationResult> GetNewsList();
    }
}
