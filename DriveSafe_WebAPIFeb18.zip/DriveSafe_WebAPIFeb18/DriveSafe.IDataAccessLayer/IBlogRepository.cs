﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IBlogRepository
    {
        Task<OperationResult> GetBlog();
        Task<OperationResult> GetBlogForUser();

        Task<OperationResult> PostBlog(Blogs blog);

        Task<OperationResult> PutBlog();

        Task<OperationResult> UpdateBlog(int id, Blogs blog);

        Task<OperationResult> DeleteBlog(int BlogId);

    }
}
