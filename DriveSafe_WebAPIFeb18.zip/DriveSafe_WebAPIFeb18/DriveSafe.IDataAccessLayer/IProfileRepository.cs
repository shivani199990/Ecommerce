﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IProfileRepository
    {
        Task<OperationResult> GetAdminProfile(String EmailId);

        Task<OperationResult> GetUserProfile(String EmailId);

        Task<OperationResult> UpdateUserProfile(User user);



        Task<OperationResult> UpdateAdminProfile(Admin admin);
    }
}
