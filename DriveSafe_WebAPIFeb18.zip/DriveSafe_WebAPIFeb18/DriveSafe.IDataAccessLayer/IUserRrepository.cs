﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.DataAccessLayer
{
    public interface IUserRepository
    {
        Task<OperationResult> GetUserDetails(String EmailId);

        Task<OperationResult> SetUserDetails(User user);

        Task<OperationResult> StoreUserLoginDetails(UserLogin userLogin);
        Task<OperationResult> ResetPassword(ChangePassword changePassword);
        Task<OperationResult> UpdatePassword(UserLogin userLogin);
    }
}
