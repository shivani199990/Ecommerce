﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IAdminRepository
    { 
            Task<OperationResult> GetAdminDetails(String EmailId);

            Task<OperationResult> SetAdminDetails(Admin admin);
            Task<OperationResult> StoreAdminLoginDetails(AdminLogin adminLogin);
            Task<OperationResult> VerifyAccessKey(String accessKey);
            Task<OperationResult> ResetPassword(ChangePassword changePassword);
            Task<OperationResult> UpdatePassword(AdminLogin adminLogin);
    }
}
