﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IEventsRepository
    {
        Task<OperationResult> PostEvents(Events events);
        Task<OperationResult> Delete(int id);
        Task<OperationResult> UpdateEvents(int id, Events events);
        Task<OperationResult> GetEventsList();
    }
}
