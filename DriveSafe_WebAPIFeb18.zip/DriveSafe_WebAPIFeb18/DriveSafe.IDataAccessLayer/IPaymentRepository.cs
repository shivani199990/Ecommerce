﻿using DriveSafe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.IDataAccessLayer
{
    public interface IPaymentRepository
    {
        OperationResult GetAccountHolderOfCard(PaymentDetails paymentDetails);
        OperationResult CheckBalance(decimal amount, long accountNumber);
        OperationResult UpdateBalance(long accountNumber, decimal amount);
        OperationResult GetPaymentDetails(string fromDate, string toDate);
        OperationResult GetTotalPaymentDetails(string fromDate, string toDate);
    }
}
