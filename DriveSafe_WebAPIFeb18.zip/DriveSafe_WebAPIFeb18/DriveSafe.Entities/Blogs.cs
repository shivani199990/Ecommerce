﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.Entities
{
    public class Blogs
    {
        public int BlogId { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string BlogTitle { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string BlogContent { get; set; }

        public string BlogDateTime { get; set; }

        [Required(ErrorMessage = "Mandatory Field", AllowEmptyStrings = false)]
        public string UserEmail { get; set; }

        public bool IsApproval { get; set; }

        public bool IsDelete { get; set; }
    }
}
