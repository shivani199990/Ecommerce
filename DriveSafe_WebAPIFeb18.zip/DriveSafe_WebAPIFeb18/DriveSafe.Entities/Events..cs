﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.Entities
{
    public class Events
    {
       
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "EventsName should not be empty")]
        public string EventName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Venue should not be empty")]
        public string Venue { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Date should not be empty")]
        public String Date { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Time should not be empty")]
        public String Time { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Descriptions should not be empty")]
        public string Description { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "EmailId should not be empty")]
        public string EmailId { get; set; }


    }
}
