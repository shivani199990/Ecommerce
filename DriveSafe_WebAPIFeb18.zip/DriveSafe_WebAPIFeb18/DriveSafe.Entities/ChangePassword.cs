﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.Entities
{
    public class ChangePassword
    {
        /// <summary>
        /// Get and Set EmailId of ChangePassword
        /// </summary>
        /// 
        [Required(AllowEmptyStrings = false, ErrorMessage = "EmailID should not be empty")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$", ErrorMessage = "E-mail is not valid")]
        public string EmailId { get; set; }
        /// <summary>
        /// Get and Set PhoneNumber of Change Password
        /// </summary>
        public string PhoneNumber { get; set; }
    }
}
