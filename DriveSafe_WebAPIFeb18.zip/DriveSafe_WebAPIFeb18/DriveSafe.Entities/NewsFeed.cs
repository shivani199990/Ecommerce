﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.Entities
{
    public class NewsFeed
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "HeadLines should not be empty")]

        public string HeadLines { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Descriptions should not be empty")]

        public string Description { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Link should not be empty")]

        public string Link { get; set; }
        public int Id { get; set; }
    }
}
