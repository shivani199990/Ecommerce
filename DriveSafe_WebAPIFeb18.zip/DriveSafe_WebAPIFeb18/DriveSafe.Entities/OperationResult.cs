﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DriveSafe.Entities
{
    public class OperationResult
    {
        /// <summary>
        /// Get and Set Message of Operation result
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Get and Set Status of Opertaion Result
        /// </summary>
        public bool Status { get; set; }
        /// <summary>
        /// Get and Set StatusCode of Operation Result
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }
        /// <summary>
        /// Get and set Data of Opeartion Result
        /// </summary>
        public Object Data { get; set; }
    }
}
