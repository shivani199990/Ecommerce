﻿using IPLAuction.Entity;
using IPLAuction.SystemManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IPLAuction.Client
{
    class UserInterface
    {
        public static void Main(string[] args)
        {
            bool toContinue = true;
            do
            {
                Console.WriteLine("Select option:");
                Console.WriteLine("===============================");
                Console.WriteLine("Enter 1 to add new player:");
                Console.WriteLine("Enter 2 to diaplay team details:");
                Console.WriteLine("Enter 3 for exit");
                Console.WriteLine("===============================");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Player player = new Player();
                    Console.WriteLine("Add Player!!");
                    Console.WriteLine("--------------------------------");
                    Console.WriteLine("Enter Player Name:");
                    player.Name = Console.ReadLine();
                    Console.WriteLine("Enter Category:");
                    player.Category = Console.ReadLine();
                    Console.WriteLine("Enter Highest Score");
                    player.HighestScore = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Best Figure");
                    player.BestFigure =Console.ReadLine();
                    Console.WriteLine("Enter Team Name");
                    player.TeamName = Console.ReadLine();

                    PlayerUtil pUtil = new PlayerUtil();
                    int playerNumber = 0;
                    bool isPlayerAdded = pUtil.AddPlayer(player, out playerNumber);

                    if (isPlayerAdded)
                    {
                        Console.WriteLine("{0} Player added successfully.", playerNumber);
                    }
                    else
                    {
                        Console.WriteLine("Unable to add player.");
                    }
                }
                else if (choice == 2)
                {
                    string teamName = Console.ReadLine();
                    TeamUtil tUtil = new TeamUtil();
                    List<Player> playerList = tUtil.GetTeamLineup(teamName);
                    foreach(Player p in playerList){
                        Console.WriteLine(p);
                    }
                }
                else if (choice == 3)
                {
                    toContinue = false;
                }
                else
                {
                    Console.WriteLine("Wrong choice");
                }
            } while (toContinue);
        }
    }
}
