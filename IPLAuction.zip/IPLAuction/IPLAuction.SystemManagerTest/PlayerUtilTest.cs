﻿using IPLAuction.CustomException;
using IPLAuction.Entity;
using IPLAuction.SystemManager;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLAuction.SystemManagerTest
{
 [TestClass]
    public class PlayerUtilTest
    {
        PlayerUtil playerUtil;
        public PlayerUtilTest()
        {
            playerUtil = new PlayerUtil();
           
        }
        [TestMethod]
        [ExpectedException(typeof(InvalidCategoryException))]
        public void PlayerUtil_AddPlayer_ValidateTest()
        {
            Player player = new Player()
            {
                Name = "MS",
                HighestScore = 111,
                BestFigure = "4/6",
                Category = "WICKETKEEPER",
                TeamName = "RCB"
            };
            int number;
            bool isAdded = playerUtil.AddPlayer(player, out number);
            Assert.IsFalse(isAdded);
        }
    
    }
}
