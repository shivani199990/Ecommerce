﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLAuction.CustomException
{
    public class InvalidCategoryException : Exception
    {
        public InvalidCategoryException()
        {

        }
        InvalidCategoryException(string message) : base(message)
        {

        }
        InvalidCategoryException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
