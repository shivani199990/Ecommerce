﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLAuction.CustomException
{
    public class NotABatsManException : Exception
    {
          NotABatsManException()
        {

        }
        public NotABatsManException(string message) : base(message)
        {

        }
        public NotABatsManException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
