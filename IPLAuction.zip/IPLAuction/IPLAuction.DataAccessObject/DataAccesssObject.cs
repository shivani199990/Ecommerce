﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPLAuction.Entity;
using System.Data.SqlClient;
using System.Data;

namespace IPLAuction.DataAccessObject
{
    public class DataAccesssObject : DataAccess
    {
        string connectionString = "Data source = G1C2ML14267; database = Players_DB; Integrated Security = true";
        SqlConnection connection = null;
        public DataAccesssObject()
        {
            connection = new SqlConnection(connectionString);
           
        }
        public bool AddPlayer(Player player, out int playerNumber)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("SPINSERTPROCEDURE", connection) { CommandType = CommandType.StoredProcedure };
            command.Parameters.AddWithValue("@PLAYERNAME",player.Name);
            command.Parameters.AddWithValue("@CATEGORY", player.Category);
            command.Parameters.AddWithValue("@HIGHESTSCORE", player.HighestScore);
            command.Parameters.AddWithValue("@BESTFIGURE", player.BestFigure);
            command.Parameters.AddWithValue("@TEAMNAME", player.TeamName);

            SqlParameter output = new SqlParameter("@PLAYER_NO", SqlDbType.Int) { Direction = ParameterDirection.Output };
            command.Parameters.Add(output);

            int rowsAffected = command.ExecuteNonQuery();

            playerNumber   = Convert.ToInt32(output.Value.ToString());

            connection.Close();
            if (rowsAffected > 0)
                return true;
            return false;
        }
        public List<string> GetTeamName()
        {
            connection.Open();
            SqlCommand command = new SqlCommand("SP_GET_TEAM", connection) { CommandType = CommandType.StoredProcedure };

            SqlDataReader sqlRdr = command.ExecuteReader();

            List<string> team = new List<string>();
            if (sqlRdr.HasRows)
            {
                while (sqlRdr.Read())
                {
                    team.Add(sqlRdr.GetString(0));

                }
            }
            else
            {
                Console.WriteLine("Teams are not there.");
            }
            connection.Close();
            return team;
        }
        public bool isPlayerExists(Player player)
        {
            SqlCommand command = new SqlCommand("SP_CHECKPLAYER", connection) { CommandType = CommandType.StoredProcedure };
            command.Parameters.AddWithValue("@PLAYERNAME", player.Name);
            command.Parameters.AddWithValue("@CATEGORY", player.Category);
            command.Parameters.AddWithValue("@TEAMNAME", player.TeamName);

            connection.Open();
            int var = Convert.ToInt32(command.ExecuteScalar().ToString());
            connection.Close();

            if (var > 0)
                return true;
            return false;
        }

        public List<Player> GetTeamLineUp(string teamName)
        {
            List<Player> playerList = new List<Player>();
            connection.Open();

            SqlCommand command = new SqlCommand("SP_RETURNLINEUP", connection) { CommandType = CommandType.StoredProcedure };
            command.Parameters.AddWithValue("@TEAMNAME", teamName);

            SqlDataReader sqlRdr = command.ExecuteReader();

            if (sqlRdr.HasRows)
            {
                while (sqlRdr.Read())
                {
                    playerList.Add(new Player() { Name = sqlRdr.GetString(0) });
                }
            }
            else
            {
                Console.WriteLine("Players are not there.");
            }
            connection.Close();
            return playerList;
        }

        public bool AddPlayer(Player player)
        {
            throw new NotImplementedException();
        }
    }
}
