﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLAuction.Entity
{
    public class Player
    {
        public string Name { get; set; }
        public string Category { get; set; }
        public int HighestScore { get; set; }
        public string BestFigure { get; set; }
        public string TeamName { get; set; }
    }
}
