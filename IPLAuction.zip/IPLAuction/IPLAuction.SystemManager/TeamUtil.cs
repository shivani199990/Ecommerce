﻿using IPLAuction.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPLAuction.DataAccessObject;
using IPLAuction.CustomException;

namespace IPLAuction.SystemManager
{
    public class TeamUtil
    {
        private List<string> teamName;
        public TeamUtil()
        {
            teamName = new DataAccesssObject().GetTeamName();
        }
        public List<Player> GetTeamLineup(string teamName)
        {
            if (!teamName.Contains(teamName))
            {
                throw new InvalidTeamNameException("Invalid team name.");
            }
            DataAccesssObject dao = new DataAccesssObject();
            return dao.GetTeamLineUp(teamName);
        }
    }
}
