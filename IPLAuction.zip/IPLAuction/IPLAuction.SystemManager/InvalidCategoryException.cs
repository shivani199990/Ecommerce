﻿using System;
using System.Runtime.Serialization;

namespace IPLAuction.SystemManager
{
    [Serializable]
    internal class InvalidCategoryException : Exception
    {
        public InvalidCategoryException()
        {
        }

        public InvalidCategoryException(string message) : base(message)
        {
        }

        public InvalidCategoryException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidCategoryException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}