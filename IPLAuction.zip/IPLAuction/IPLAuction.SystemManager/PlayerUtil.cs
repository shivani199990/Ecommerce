﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPLAuction.Entity;
using IPLAuction.DataAccessObject;
using IPLAuction.CustomException;

namespace IPLAuction.SystemManager
{
    public class PlayerUtil
    {

        private List<string> teamName;

        public PlayerUtil()
        {
            teamName = new DataAccesssObject().GetTeamName();
        }
        public bool AddPlayer(Player player, out int playerNumber)
        {
            DataAccesssObject dao = new DataAccesssObject();
            try
            {
                if(player.Category != "BATSMAN" && player.Category != "BOWLER" && player.Category != "ALLROUNDER")
                {
                    throw new InvalidCategoryException("Invalid Category name.");
                }
                if (!teamName.Contains(player.TeamName))
                {
                    throw new InvalidTeamNameException("Invalid team name.");

                }
                if((player.Category == "BATSMAN" && player.HighestScore < 50) || (player.Category == "BATSMAN" && player.HighestScore > 200))
                {
                    throw new NotABatsManException("Invalid batsman.");
                }
                if ((player.Category == "BOWLER" && player.BestFigure == null) || (player.Category == "BOWLER" && player.HighestScore < 50))
                {
                    throw new NotABowlerException("Invalid bowler.");
                }
                if (dao.isPlayerExists(player))
                {
                    throw new DuplicateEntryException("Player already exists.");
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception occurred.");
               
            }
            return dao.AddPlayer(player, out playerNumber);
        }
    }
}
